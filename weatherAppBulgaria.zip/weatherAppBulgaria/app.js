const key = "af6dfa3f95a8681bc83b6bb6b1fb615b";

const locations = [
  ['burgas,', 42.510578, 27.461014],
  ['sofia', 42.698334, 23.319941],
  ['varna', 43.204666, 27.910543],
  ['plovdiv,', 42.136097, 24.742168],
  ['blagoevgrad', 42.0166702, 23.1000004],
  ['vTurnovo', 43.075672, 25.617151],
  ['vidin,', 43.99, 22.8725],
  ['vraca', 43.21, 23.5625],
  ['gabrovo', 42.87472, 25.33417],
  ['dobrich,', 43.56667, 27.83333],
  ['kurdzhali', 41.65, 25.36667],
  ['kyustendil', 42.28389, 22.69111],
  ['lovech,', 43.13333, 24.71667],
  ['montana', 43.4124985, 23.2250004],
  ['pazardzhik', 42.2, 24.33333],
  ['pernik,', 42.6, 23.03333],
  ['pleven', 43.41667, 24.61667],
  ['razgrad', 43.53333, 26.51667],
  ['ruse', 43.85639, 25.97083],
  ['silistra', 44.114727, 27.267191],
  ['sliven', 42.68583, 26.32917],
  ['smolyan', 41.58528, 24.69194],
  ['sZagora', 42.43278, 25.64194],
  ['targovishte', 43.2512, 26.57215],
  ['haskovo', 41.93415, 25.55557],
  ['shumen', 43.283333, 26.933332],
  ['yambol', 42.492603, 26.501442],
];

async function initMap() {
  var bulgaria = {
    lat: 42.7249925,
    lng: 25.4833039
  };

  await getWeather();

  var map = new google.maps.Map(
    document.getElementById('map'), {
      zoom: 7.7,
      center: bulgaria
    });

  var marker, i;

  var infowindow = new google.maps.InfoWindow();

  for (i = 0; i < locations.length; i++) {
    marker = new google.maps.Marker({
      position: new google.maps.LatLng(locations[i][1], locations[i][2]),
      map: map,
      title: locations[i][0]
    });

    google.maps.event.addListener(marker, 'mouseover', (function(marker, i) {
      return function() {
        marker.setIcon(`icons/${locations[i][3].icon}.png`);
      }
    })(marker, i));

    google.maps.event.addListener(marker, 'mouseout', (function(marker, i) {
      return function() {
        marker.setIcon();
      }
    })(marker, i));

    google.maps.event.addListener(marker, 'click', (function(marker, i) {
      return function() {
        infowindow.setContent(locations[i][3].main);
        infowindow.open(map, marker);
      }
    })(marker, i));
  }
}

async function getWeather() {
  for (i = 0; i < locations.length; i++) {
    let weather = {
      temperature: {
        unit: 'celsius'
      }
    };

    var latitude = locations[i][1];
    var longitude = locations[i][2];
    let api = `http://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=${key}`;

    const res = await fetch(api);
    const data = await res.json();

    temp = convertKelvinToCelsius(data.main.temp);
    min_temp = convertKelvinToCelsius(data.main.temp_min);
    max_temp = convertKelvinToCelsius(data.main.temp_max);

    let main = `Humidity: ${data.main.humidity};
                Pressure: ${data.main.pressure};
                Current Temp: ${temp};
                Max. Temp: ${max_temp};
                Min. Temp: ${min_temp}`

    weather.description = data.weather[0].description;
    weather.main = main;
    weather.icon = data.weather[0].icon;
    weather.city = data.name;
    weather.country = data.sys.country;

    locations[i].push(weather);
  }
}

function convertKelvinToCelsius(kelvin) {
	if (kelvin < (0)) {
		return 'below absolute zero (0 K)';
	} else {
        res = kelvin - 273.15;
		return Math.round(res);
	}
}
